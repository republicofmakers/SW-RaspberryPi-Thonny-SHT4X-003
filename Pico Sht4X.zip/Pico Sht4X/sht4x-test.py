

from machine import I2C, Pin, SPI
import time
from ST7735 import TFT
from sysfont import sysfont
from sht4x import SHT4X  # Your driver

# --- SPI0 for TFT ---
spi = SPI(0, baudrate=20000000, polarity=0, phase=0,
          sck=Pin(18), mosi=Pin(19), miso=None)
tft = TFT(spi, 21, 20, 22)  # DC, RST, CS
tft.rgb(True)
tft.init_7735(tft.GREENTAB80x160)

# --- I2C1 for SHT4x Sensor ---
i2c = I2C(1, sda=Pin(2), scl=Pin(3), freq=100_000)

# --- Intro Screen ---
tft.fill(TFT.BLACK)

tft.text((0, 00), "RP2040", TFT.RED, sysfont, 2)
tft.text((0, 20), "SHT4X TEST", TFT.RED, sysfont, 2)
tft.text((0, 40), "Ceyhun Pempeci", TFT.BLUE, sysfont, 2)
tft.text((0, 65), "2025", TFT.GREEN, sysfont, 2)

time.sleep(5)

# --- Init SHT4x Sensor ---
try:
    sht = SHT4X(i2c)
    print("Sensor initialized.")
except Exception as e:
    tft.fill(TFT.BLACK)
    tft.text((10, 30), "Init Failed", TFT.RED, sysfont, 2)
    print("SHT4x init error:", e)
    raise

# --- Main Loop ---
while True:
    try:
        temp = sht.temperature
        hum = sht.relative_humidity
        print("Temp: {:.2f} C, Hum: {:.2f} %".format(temp, hum))

        tft.fill(TFT.BLACK)
        tft.text((10, 5), "TEMPERATURE", TFT.RED, sysfont, 2)
        tft.text((10, 30), "{:.2f} C".format(temp), TFT.GREEN, sysfont, 2)
        time.sleep(2)

        tft.fill(TFT.BLACK)
        tft.text((10, 5), "HUMIDITY", TFT.RED, sysfont, 2)
        tft.text((10, 30), "{:.2f} %".format(hum), TFT.GREEN, sysfont, 2)
        time.sleep(2)

    except Exception as e:
        print("Sensor error:", e)
        tft.fill(TFT.BLACK)
        tft.text((10, 30), "Sensor Error", TFT.RED, sysfont, 2)
        time.sleep(2)
